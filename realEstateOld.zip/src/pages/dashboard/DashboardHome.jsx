import FinanceMap from "../FinanceMap/FinanceMap.jsx";

const STATUS_CLASS = {
  متاح: "badge--available",
  مباع: "badge--sold",
  معلق: "badge--pending",
  محجوز: "badge--reserved",
  "موافق عليه": "badge--approved",
  مرفوض: "badge--rejected",
  "قيد المراجعة": "badge--reviewing",
  "عميل نشط": "badge--active",
  مكتمل: "badge--completed",
  "في المفاوضات": "badge--negotiating",
};

const MONTHS = ["نوفمبر", "ديسمبر", "يناير", "فبراير", "مارس", "أبريل","مايو","يونيو","يوليو" ];
const BARS = [45, 60, 38, 72, 55, 80,66, 60, 38];
const VALUES = ["4.5M", "6.1M", "3.8M", "7.2M", "5.5M", "8.1M","6.6M", "6.1M", "3.8M"];

const Badge = ({ label }) => {
  const mod = STATUS_CLASS[label] ?? "badge--default";
  return <span className={`badge ${mod}`}>{label}</span>;
};

const StatCard = ({ label, value, badge, badgeType }) => (
  <div className="stat-card">
    <div className="stat-label">{label}</div>
    <div className="stat-value">{value}</div>
    <span className={`stat-badge stat-badge--${badgeType}`}>{badge}</span>
  </div>
);

function exportToCSV(data) {
  if (!data?.length) {
    return;
  }

  const headers = Object.keys(data[0]);
  const rows = data.map((row) =>
    headers
      .map((field) => {
        let value = row[field];

        if (value instanceof Date) {
          value = value.toLocaleDateString("ar-EG");
        }

        value = String(value ?? "");
        return `"${value.replace(/"/g, '""')}"`;
      })
      .join(",")
  );

  const csvContent = [headers.join(","), ...rows].join("\n");
  const blob = new Blob(["\uFEFF" + csvContent], {
    type: "text/csv;charset=utf-8;",
  });

  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "mortgage_requests.csv";
  link.click();
}

export default function DashboardHome({
  units,
  mortgageRequests,
  clients,
  onAddUnit,
}) {
  const soldUnits = units.filter((unit) => unit.status === "مباع");
  const availableUnits = units.filter((unit) => unit.status === "متاح").length;
  const activeRequests = mortgageRequests.filter(
    (request) => request.status === "قيد المراجعة"
  ).length;
  const approvedRequests = mortgageRequests.filter(
    (request) => request.status === "موافق عليه"
  ).length;
  const revenue = soldUnits.reduce((sum, unit) => sum + unit.price, 0);
  const averageUnitPrice = units.length
    ? Math.round(units.reduce((sum, unit) => sum + unit.price, 0) / units.length)
    : 0;
  const approvalRate = mortgageRequests.length
    ? Math.round((approvedRequests / mortgageRequests.length) * 100)
    : 0;
  const revenueLabel =
    revenue >= 1_000_000
      ? `${(revenue / 1_000_000).toFixed(1)}M`
      : revenue.toLocaleString("ar-EG");
  const averageUnitLabel =
    averageUnitPrice >= 1_000_000
      ? `${(averageUnitPrice / 1_000_000).toFixed(2)}M`
      : averageUnitPrice.toLocaleString("ar-EG");

  return (
    <div className="dashboard">
 

      <div className="dashboard-insights">
        <div className="dashboard-insight-card">
          <span className="dashboard-insight-label">وحدات متاحة الآن</span>
          <strong className="dashboard-insight-value">{availableUnits}</strong>
          <p className="dashboard-insight-note">جاهزة للعرض والمتابعة المباشرة</p>
        </div>

        <div className="dashboard-insight-card">
          <span className="dashboard-insight-label">متوسط سعر الوحدة</span>
          <strong className="dashboard-insight-value">
            {averageUnitLabel} ج.م
          </strong>
          <p className="dashboard-insight-note">قراءة سريعة لمستوى التسعير الحالي</p>
        </div>

        <div className="dashboard-insight-card">
          <span className="dashboard-insight-label">نسبة الموافقات</span>
          <strong className="dashboard-insight-value">{approvalRate}%</strong>
          <p className="dashboard-insight-note">من إجمالي طلبات التمويل المسجلة</p>
        </div>
      </div>

      <div className="stats-grid">
        <StatCard
          label="إجمالي الوحدات"
          value={units.length}
          badge="↑ 12 هذا الشهر"
          badgeType="up"
        />
        <StatCard
          label="وحدات مباعة"
          value={soldUnits.length}
          badge="↑ 8% من الشهر الماضي"
          badgeType="up"
        />
        <StatCard
          label="طلبات تمويل نشطة"
          value={activeRequests}
          badge="↓ 3 معلقة"
          badgeType="down"
        />
        <StatCard
          label="إجمالي المبيعات"
          value={`${revenueLabel} ج.م`}
          badge="↑ 18% هذا الربع"
          badgeType="up"
        />
      </div>

      <div className="dashboard-two-col dashboard-two-col--feature">
        <div className="card dashboard-map-card">
        <div className="map-header">
          <div>
            <div className="card-title">مواقع الوحدات</div>
          </div>

          <span className="map-link">تحديث مباشر</span>
        </div>

  <div className="mini-map">
      <div className="map-pin pin-1"></div>
      <div className="map-pin pin-2"></div>
      <div className="map-pin pin-3"></div>
      <div className="map-pin pin-4"></div>
      <div className="map-pin pin-5"></div>
      <div className="map-pin pin-6"></div>
      <div className="map-pin pin-7"></div>
      <div className="map-pin pin-8"></div>
  </div>
</div>

        <div className="card">
          <div className="card-title">مبيعات الأشهر الستة</div>
          <div className="sales-bars-list">
            {MONTHS.map((month, index) => (
              <div key={month} className="sales-bar-row">
                <div className="sales-bar-label">{month}</div>
                <div className="sales-bar-track">
                  <div
                    className="sales-bar-fill"
                    style={{ width: `${BARS[index]}%` }}
                  />
                </div>
                <div className="sales-bar-value">{VALUES[index]}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="dashboard-two-col">
        <div className="card">
          <div className="card-title">أحدث الوحدات</div>
          <div className="list-rows">
            {[...units].reverse().slice(0, 4).map((unit) => (
              <div key={unit.id} className="unit-row">
                <div className="unit-row-main">
                  <div className="unit-row-name">{unit.name}</div>
                  <div className="unit-row-sub">
                    {unit.area} · {unit.size} م²
                  </div>
                </div>

                <div className="unit-row-right">
                  <div className="unit-row-price">
                    {(unit.price / 1_000_000).toFixed(2)}M ج.م
                  </div>
                  <Badge label={unit.status} />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-title">طلبات التمويل الأخيرة</div>
          <div className="list-rows">
            {mortgageRequests.map((request) => (
              <div key={request.id} className="mortgage-row">
                <div className="mortgage-row-main">
                  <div className="mortgage-row-ref">#{request.refNumber}</div>
                  <div className="mortgage-row-name">{request.clientName}</div>
                </div>

                <div className="mortgage-row-right">
                  <div className="mortgage-row-amount">
                    {(request.amount / 1000).toFixed(0)}K ج.م
                  </div>
                  <Badge label={request.status} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="clients-card">
        <div className="card-title">أحدث العملاء</div>
        <div>
          {clients.map((client, index) => (
            <div
              key={client.id}
              className={`client-row${
                index < clients.length - 1 ? " client-row--bordered" : ""
              }`}
            >
              <div className="client-avatar">{client.name.slice(0, 2)}</div>
              <div className="client-info">
                <div className="client-name">{client.name}</div>
                <div className="client-interest">{client.interest}</div>
              </div>
              <div className="client-status">
                <Badge label={client.status} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
